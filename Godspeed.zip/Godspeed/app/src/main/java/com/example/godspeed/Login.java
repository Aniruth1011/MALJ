package com.example.godspeed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

public class Login extends AppCompatActivity {

    private EditText phoneInput;
    private EditText passcodeInput;
    private Button loginButton;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phoneInput = findViewById(R.id.username);
        passcodeInput = findViewById(R.id.passcode);
        loginButton = findViewById(R.id.login);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar = findViewById(R.id.progressBar);
                progressBar.setVisibility(View.VISIBLE);
                loginButton.setBackgroundColor(getResources().getColor(R.color.black));
                String phone = phoneInput.getText().toString();
                String passcode = passcodeInput.getText().toString();

                // TODO: Validate Input

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            java.net.URL url = new URL("http://10.5.229.25:5000/api/login");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("POST");
                            conn.setDoOutput(true);
                            conn.setDoInput(true);
                            conn.setRequestProperty("Content-Type", "application/json; utf-8");
                            conn.setRequestProperty("Accept", "application/json");

                            JSONObject jsonParam = new JSONObject();
                            jsonParam.put("phone_number", phone);
                            jsonParam.put("password", passcode);

                            OutputStream os = conn.getOutputStream();
                            byte[] input = jsonParam.toString().getBytes("utf-8");
                            os.write(input, 0, input.length);

                            os.close();

                            int responseCode = conn.getResponseCode();
                            if (responseCode == HttpsURLConnection.HTTP_OK) {
                                // TODO: Handle successful login
                                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                                String inputLine;
                                StringBuffer response = new StringBuffer();

                                while ((inputLine = in.readLine()) != null) {
                                    response.append(inputLine);
                                }
                                in.close();

                                JSONObject jsonResponse = new JSONObject(response.toString());
                                String message = jsonResponse.getString("message");
                                if (message.equals("Login successful")) {
                                    // Open MainActivity
                                    Intent intent = new Intent(Login.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    // Display error message for unsuccessful login
                                    runOnUiThread(new Runnable() {
                                        public void run() {
                                            Toast.makeText(Login.this, "Login unsuccessful", Toast.LENGTH_SHORT).show();
                                            progressBar.setVisibility(View.INVISIBLE);
                                            loginButton.setBackgroundColor(getResources().getColor(R.color.black));
                                        }
                                    });
                                }
                            } else {
                                // TODO: Handle unsuccessful login
                                Toast.makeText(Login.this, "Login unsuccessful. Connection failed.", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.INVISIBLE);
                                loginButton.setBackgroundColor(getResources().getColor(R.color.black));
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (isTaskRoot()) {
            // If `StartScreen` is not in the back stack, start the `StartScreen` activity
            Intent i1 = new Intent(Login.this, StartScreen.class);
            startActivity(i1);
        } else {
            // If `StartScreen` is in the back stack, finish the current activity
            super.onBackPressed();
        }
    }

}
