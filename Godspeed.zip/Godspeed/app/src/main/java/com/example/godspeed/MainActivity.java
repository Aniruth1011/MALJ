package com.example.godspeed;

import android.Manifest;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    JSONObject jsonData = new JSONObject();


    private SensorManager mSensorManager;
    private Sensor mAccelerometer, mGyroscope;
    private TextView stopwatchTextView, speedTextView, gyroscopeTextView, locationTextView;
    private Button startButton, stopButton;
    private Handler handler;
    private long startTime, elapsedTime;
    private LocationManager locationManager;
    private LocationListener locationListener;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationTextView = findViewById(R.id.locationTextView);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                locationTextView.setText(String.format("Location: Lat = %.6f, Long = %.6f", location.getLatitude(), location.getLongitude()));
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                // Handle status changes if needed
            }

            @Override
            public void onProviderEnabled(String provider) {
                // Handle provider enabled if needed
            }

            @Override
            public void onProviderDisabled(String provider) {
                // Handle provider disabled if needed
            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (lastKnownLocation != null) {
                locationTextView.setText(String.format("Location: Lat = %.6f, Long = %.6f", lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude()));

                try {
                    jsonData.put("location", new JSONObject()
                            .put("latitude", lastKnownLocation.getLatitude())
                            .put("longitude", lastKnownLocation.getLongitude()));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }



        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mGyroscope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        stopwatchTextView = findViewById(R.id.stopwatchTextView);
        speedTextView = findViewById(R.id.speedTextView);
        gyroscopeTextView = findViewById(R.id.gyroscopeTextView);
        startButton = findViewById(R.id.start_button);
        stopButton = findViewById(R.id.stop_button);
        handler = new Handler();
    }

    public void onClickStart(View view) {
        startTime = System.currentTimeMillis();
        handler.postDelayed(timerRunnable, 0);
        startButton.setEnabled(false);
        stopButton.setEnabled(true);
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(this, mGyroscope, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void onClickStop(View view) {
        handler.removeCallbacks(timerRunnable);
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            // Update UI with accelerometer values
            // Calculate speed from accelerometer data and update speedTextView
            float[] values = event.values;
            float x = values[0];
            float y = values[1];
            float z = values[2];
            speedTextView.setText(String.format("Accelerometer: X = %.2f, Y = %.2f, Z = %.2f", x, y, z));
            // Calculate speed from accelerometer data
            try {
                jsonData.put("accelerometer_value", new JSONObject()
                        .put("acc_x", x)
                        .put("acc_y", y)
                        .put("acc_z", z));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            // ...
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            // Update UI with gyroscope values
            // Update gyroscopeTextView
            float[] values = event.values;
            float x = values[0];
            float y = values[1];
            float z = values[2];
            gyroscopeTextView.setText(String.format("Gyroscope: X = %.2f, Y = %.2f, Z = %.2f", x, y, z));
            try {
                jsonData.put("gyroscope_value", new JSONObject()
                        .put("gyro_x", x)
                        .put("gyro_y", y)
                        .put("gyro_z", z));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        sendPostRequest("http://10.5.229.25:5000/api/stream_data/12345", jsonData);
    }

    private final OkHttpClient client = new OkHttpClient();

    public void sendPostRequest(String url, JSONObject json) {
        RequestBody body = RequestBody.create(json.toString(), MediaType.parse("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                } else {
                    // Do something with the response.
                }
            }
        });
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle accuracy changes if needed
    }

    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            // Update stopwatchTextView
            elapsedTime = System.currentTimeMillis() - startTime;
            int minutes = (int) (elapsedTime / 1000) / 60;
            int seconds = (int) (elapsedTime / 1000) % 60;
            int milliseconds = (int) (elapsedTime % 1000);
            stopwatchTextView.setText(String.format("%02d:%02d:%03d", minutes, seconds, milliseconds));
            handler.postDelayed(this, 0);
        }
    };
}